# DinoDex_API
API REST para gerenciamento de fósseis de dinossauros, com cadastro de espécimes, museus e taxons

from dinodex_api.especime.models import EspecimeModel
from dinodex_api.taxons.models   import TaxonModel
from dinodex_api.museus.models    import MuseuModel

